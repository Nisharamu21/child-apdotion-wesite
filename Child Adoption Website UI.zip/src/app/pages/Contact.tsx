import { useState } from "react";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle, 
  Send,
  CheckCircle
} from "lucide-react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      });
    }, 3000);
  };

  const updateFormData = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "24/7 Helpline",
      details: ["1-800-ADOPT-NOW", "(1-800-236-7866)"],
      description: "Always available for urgent questions",
    },
    {
      icon: Mail,
      title: "Email Us",
      details: ["info@heartshomes.org", "support@heartshomes.org"],
      description: "Response within 24 hours",
    },
    {
      icon: MapPin,
      title: "Visit Our Office",
      details: ["123 Hope Street", "New York, NY 10001"],
      description: "By appointment only",
    },
    {
      icon: Clock,
      title: "Office Hours",
      details: ["Monday - Friday: 9 AM - 6 PM", "Saturday: 10 AM - 4 PM"],
      description: "Closed on major holidays",
    },
  ];

  const offices = [
    {
      city: "New York, NY",
      address: "123 Hope Street, NY 10001",
      phone: "(212) 555-0100",
      email: "ny@heartshomes.org",
    },
    {
      city: "Los Angeles, CA",
      address: "456 Sunshine Blvd, CA 90001",
      phone: "(310) 555-0200",
      email: "la@heartshomes.org",
    },
    {
      city: "Chicago, IL",
      address: "789 Family Lane, IL 60601",
      phone: "(312) 555-0300",
      email: "chicago@heartshomes.org",
    },
    {
      city: "Houston, TX",
      address: "321 Caring Court, TX 77001",
      phone: "(713) 555-0400",
      email: "houston@heartshomes.org",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">Contact & Support</h1>
          <p className="text-lg text-muted-foreground">
            We're here to answer your questions and guide you on your adoption journey
          </p>
        </div>
      </section>

      {/* Contact Information Cards */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div
                  key={index}
                  className="bg-muted p-6 rounded-xl hover:shadow-lg transition-shadow"
                >
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="mb-3 text-foreground">{info.title}</h3>
                  <div className="space-y-1 mb-3">
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="text-sm text-foreground">
                        {detail}
                      </p>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">{info.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form and Live Chat */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-3xl mb-2 text-foreground">Send Us a Message</h2>
                <p className="text-muted-foreground mb-8">
                  Fill out the form below and we'll get back to you within 24 hours
                </p>

                {submitted ? (
                  <div className="bg-secondary/20 border border-secondary p-6 rounded-xl flex items-center gap-4">
                    <CheckCircle className="w-8 h-8 text-secondary flex-shrink-0" />
                    <div>
                      <h3 className="mb-1 text-foreground">Message Sent Successfully!</h3>
                      <p className="text-sm text-muted-foreground">
                        We've received your message and will respond within 24 hours.
                      </p>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="block mb-2 text-sm">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => updateFormData("name", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="John Doe"
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block mb-2 text-sm">Email Address *</label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => updateFormData("email", e.target.value)}
                          className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="john@example.com"
                        />
                      </div>
                      <div>
                        <label className="block mb-2 text-sm">Phone Number</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => updateFormData("phone", e.target.value)}
                          className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="(555) 123-4567"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block mb-2 text-sm">Subject *</label>
                      <select
                        required
                        value={formData.subject}
                        onChange={(e) => updateFormData("subject", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      >
                        <option value="">Select a subject...</option>
                        <option value="general">General Inquiry</option>
                        <option value="adoption-info">Adoption Information</option>
                        <option value="application">Application Status</option>
                        <option value="support">Post-Adoption Support</option>
                        <option value="birth-parent">Birth Parent Services</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label className="block mb-2 text-sm">Message *</label>
                      <textarea
                        required
                        value={formData.message}
                        onChange={(e) => updateFormData("message", e.target.value)}
                        rows={6}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                        placeholder="Tell us how we can help you..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-primary text-white px-6 py-4 rounded-lg hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
                    >
                      <Send className="w-5 h-5" />
                      Send Message
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Live Chat Widget */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl p-8 shadow-sm sticky top-24">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl mb-3 text-center text-foreground">Need Immediate Help?</h3>
                <p className="text-sm text-muted-foreground text-center mb-6">
                  Our support team is available to chat with you in real-time during business hours.
                </p>
                <button className="w-full bg-secondary text-secondary-foreground px-6 py-3 rounded-lg hover:bg-secondary/90 transition-colors flex items-center justify-center gap-2 mb-4">
                  <MessageCircle className="w-5 h-5" />
                  Start Live Chat
                </button>
                <div className="text-center text-xs text-muted-foreground">
                  <Clock className="w-4 h-4 inline-block mr-1" />
                  Available Mon-Fri, 9 AM - 6 PM EST
                </div>

                <div className="mt-8 pt-8 border-t border-border">
                  <h4 className="mb-4 text-foreground">Quick Resources</h4>
                  <ul className="space-y-3 text-sm">
                    <li>
                      <a href="/resources" className="text-primary hover:text-primary/80 transition-colors">
                        → View FAQs
                      </a>
                    </li>
                    <li>
                      <a href="/adoption-process" className="text-primary hover:text-primary/80 transition-colors">
                        → Adoption Process Guide
                      </a>
                    </li>
                    <li>
                      <a href="/resources" className="text-primary hover:text-primary/80 transition-colors">
                        → Download Resources
                      </a>
                    </li>
                    <li>
                      <a href="/apply" className="text-primary hover:text-primary/80 transition-colors">
                        → Start Application
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Office Locations */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Our Office Locations</h2>
            <p className="text-lg text-muted-foreground">
              Visit us at any of our nationwide offices
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {offices.map((office, index) => (
              <div key={index} className="bg-muted p-6 rounded-xl">
                <MapPin className="w-8 h-8 text-primary mb-3" />
                <h3 className="mb-3 text-foreground">{office.city}</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>{office.address}</p>
                  <p className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    {office.phone}
                  </p>
                  <p className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    {office.email}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl overflow-hidden shadow-lg">
            <div className="aspect-[16/9] bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-primary mx-auto mb-4" />
                <h3 className="text-xl mb-2 text-foreground">Interactive Map</h3>
                <p className="text-sm text-muted-foreground">
                  Map integration would be displayed here
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-12 bg-destructive/10 border-y border-destructive/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-2xl mb-4 text-foreground">Emergency Support</h3>
          <p className="text-muted-foreground mb-6">
            If you are experiencing a crisis or emergency related to adoption, please call our 24/7 crisis line:
          </p>
          <a
            href="tel:1-800-236-7866"
            className="text-3xl text-primary hover:text-primary/80 transition-colors inline-flex items-center gap-3"
          >
            <Phone className="w-8 h-8" />
            1-800-ADOPT-NOW
          </a>
        </div>
      </section>
    </div>
  );
}
