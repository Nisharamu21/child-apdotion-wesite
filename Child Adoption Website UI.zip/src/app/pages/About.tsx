import { Heart, Target, Eye, Shield, Users, Award } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function About() {
  const teamMembers = [
    {
      name: "Dr. Sarah Thompson",
      role: "Director of Child Welfare",
      image: "https://images.unsplash.com/photo-1746513534315-caa52d3f462c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjB3b3JrZXIlMjBwcm9mZXNzaW9uYWwlMjBjb3Vuc2Vsb3J8ZW58MXx8fHwxNzcwMzY5NDk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      bio: "25 years experience in child welfare and family services",
    },
    {
      name: "Michael Chen",
      role: "Senior Social Worker",
      image: "https://images.unsplash.com/photo-1708762762005-dc787995aaf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZG9wdGlvbiUyMHNvY2lhbCUyMHNlcnZpY2UlMjB0ZWFtfGVufDF8fHx8MTc3MDM2OTQ5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      bio: "Licensed clinical social worker specializing in adoption placement",
    },
    {
      name: "Maria Rodriguez",
      role: "Family Counselor",
      image: "https://images.unsplash.com/photo-1746513534315-caa52d3f462c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjB3b3JrZXIlMjBwcm9mZXNzaW9uYWwlMjBjb3Vuc2Vsb3J8ZW58MXx8fHwxNzcwMzY5NDk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      bio: "Expert in post-adoption support and family integration",
    },
    {
      name: "Dr. James Wilson",
      role: "Child Psychologist",
      image: "https://images.unsplash.com/photo-1708762762005-dc787995aaf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZG9wdGlvbiUyMHNvY2lhbCUyMHNlcnZpY2UlMjB0ZWFtfGVufDF8fHx8MTc3MDM2OTQ5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      bio: "Specializing in trauma-informed care and child development",
    },
  ];

  const values = [
    {
      icon: Heart,
      title: "Compassion First",
      description: "We approach every case with empathy, understanding, and genuine care for all parties involved.",
    },
    {
      icon: Shield,
      title: "Child Safety",
      description: "The welfare and best interests of children guide every decision we make.",
    },
    {
      icon: Target,
      title: "Transparency",
      description: "We maintain clear, honest communication throughout the entire adoption process.",
    },
    {
      icon: Users,
      title: "Family Support",
      description: "Comprehensive guidance and resources for families before, during, and after adoption.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">About Hearts & Homes</h1>
          <p className="text-lg text-muted-foreground">
            For over 25 years, we've been committed to creating forever families through 
            ethical, compassionate adoption services.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-primary/10 p-3 rounded-lg">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-3xl text-foreground">Our Mission</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                To connect children in need of loving homes with families ready to provide them, 
                while ensuring ethical practices, transparency, and comprehensive support throughout 
                the adoption journey. We believe every child deserves a safe, nurturing environment 
                where they can thrive.
              </p>
            </div>
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-secondary/30 p-3 rounded-lg">
                  <Eye className="w-8 h-8 text-secondary-foreground" />
                </div>
                <h2 className="text-3xl text-foreground">Our Vision</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                A world where every child grows up in a permanent, loving family. We envision a 
                society that embraces adoption as a beautiful path to parenthood, free from stigma, 
                and supported by compassionate professionals dedicated to the well-being of children 
                and families.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Our Core Values</h2>
            <p className="text-lg text-muted-foreground">
              The principles that guide everything we do
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
                  <div className="bg-primary/10 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="text-xl mb-3 text-foreground">{value.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Ethical Commitment */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/30 rounded-full mb-4">
              <Award className="w-8 h-8 text-accent-foreground" />
            </div>
            <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">
              Our Ethical Adoption Commitment
            </h2>
          </div>
          <div className="space-y-4 text-muted-foreground">
            <p className="leading-relaxed">
              <strong className="text-foreground">Child-Centered Approach:</strong> We prioritize the best interests 
              of the child above all else. Every placement decision is made with careful consideration of the child's 
              needs, background, and future well-being.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Birth Parent Support:</strong> We treat birth parents with dignity 
              and respect, providing comprehensive counseling and ensuring informed consent. We never coerce or pressure 
              birth parents into making adoption decisions.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Transparency:</strong> All fees, timelines, and processes are clearly 
              communicated. We maintain open, honest dialogue with all parties throughout the adoption journey.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Legal Compliance:</strong> We strictly adhere to all federal, state, 
              and international adoption laws. Our agency is licensed, accredited, and regularly audited to ensure 
              compliance with the highest standards.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Post-Adoption Support:</strong> Our commitment doesn't end at placement. 
              We provide ongoing resources, counseling, and support to ensure successful family integration.
            </p>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Meet Our Team</h2>
            <p className="text-lg text-muted-foreground">
              Experienced professionals dedicated to your adoption journey
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white rounded-xl overflow-hidden shadow-lg">
                <div className="aspect-square overflow-hidden">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-lg mb-1 text-foreground">{member.name}</h3>
                  <p className="text-sm text-primary mb-3">{member.role}</p>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Accreditations */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-8 text-foreground">
            Accreditations & Memberships
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="p-6 bg-muted rounded-lg">
              <p className="text-sm">CARF Accredited</p>
            </div>
            <div className="p-6 bg-muted rounded-lg">
              <p className="text-sm">State Licensed</p>
            </div>
            <div className="p-6 bg-muted rounded-lg">
              <p className="text-sm">JCICS Member</p>
            </div>
            <div className="p-6 bg-muted rounded-lg">
              <p className="text-sm">Hague Accredited</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
