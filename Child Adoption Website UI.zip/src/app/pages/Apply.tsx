import { useState } from "react";
import { 
  User, 
  Users, 
  Home, 
  FileText, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  Upload
} from "lucide-react";

export function Apply() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Personal Information
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    // Step 2: Family Background
    maritalStatus: "",
    spouseName: "",
    occupation: "",
    spouseOccupation: "",
    householdIncome: "",
    currentChildren: "",
    // Step 3: Living Situation
    residenceType: "",
    yearsAtResidence: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    // Step 4: Adoption Preferences
    preferredAgeRange: "",
    preferredGender: "",
    openToSpecialNeeds: "",
    adoptionType: "",
    // Step 5: Documents
    documents: [] as string[],
  });

  const totalSteps = 5;

  const steps = [
    { number: 1, title: "Personal Info", icon: User },
    { number: 2, title: "Family Background", icon: Users },
    { number: 3, title: "Living Situation", icon: Home },
    { number: 4, title: "Preferences", icon: FileText },
    { number: 5, title: "Documents", icon: Upload },
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert("Application submitted successfully! Our team will contact you within 2-3 business days.");
  };

  const updateFormData = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-4 text-foreground">Adoption Application</h1>
          <p className="text-lg text-muted-foreground">
            Take the first step toward building your forever family
          </p>
        </div>
      </section>

      {/* Progress Indicator */}
      <section className="bg-white py-8 sticky top-16 z-40 border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between relative">
            {/* Progress Line */}
            <div className="absolute top-6 left-0 right-0 h-0.5 bg-border hidden md:block">
              <div
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
              />
            </div>

            {/* Steps */}
            {steps.map((step) => {
              const Icon = step.icon;
              const isCompleted = currentStep > step.number;
              const isCurrent = currentStep === step.number;

              return (
                <div key={step.number} className="flex flex-col items-center relative z-10">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors ${
                      isCompleted
                        ? "bg-primary text-white"
                        : isCurrent
                        ? "bg-primary text-white"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {isCompleted ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <Icon className="w-6 h-6" />
                    )}
                  </div>
                  <span
                    className={`text-xs md:text-sm text-center hidden md:block ${
                      isCurrent ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {step.title}
                  </span>
                  <span className="text-xs md:hidden text-muted-foreground">
                    {step.number}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Form */}
      <section className="py-12 bg-muted min-h-screen">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <form onSubmit={handleSubmit}>
            {/* Step 1: Personal Information */}
            {currentStep === 1 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl mb-6 text-foreground">Personal Information</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block mb-2 text-sm">First Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => updateFormData("firstName", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Last Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => updateFormData("lastName", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Doe"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block mb-2 text-sm">Date of Birth *</label>
                    <input
                      type="date"
                      required
                      value={formData.dateOfBirth}
                      onChange={(e) => updateFormData("dateOfBirth", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Family Background */}
            {currentStep === 2 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl mb-6 text-foreground">Family Background</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block mb-2 text-sm">Marital Status *</label>
                    <select
                      required
                      value={formData.maritalStatus}
                      onChange={(e) => updateFormData("maritalStatus", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="single">Single</option>
                      <option value="married">Married</option>
                      <option value="partnered">Partnered</option>
                      <option value="divorced">Divorced</option>
                      <option value="widowed">Widowed</option>
                    </select>
                  </div>
                  {(formData.maritalStatus === "married" || formData.maritalStatus === "partnered") && (
                    <div>
                      <label className="block mb-2 text-sm">Spouse/Partner Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.spouseName}
                        onChange={(e) => updateFormData("spouseName", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Jane Doe"
                      />
                    </div>
                  )}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block mb-2 text-sm">Your Occupation *</label>
                      <input
                        type="text"
                        required
                        value={formData.occupation}
                        onChange={(e) => updateFormData("occupation", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Software Engineer"
                      />
                    </div>
                    {(formData.maritalStatus === "married" || formData.maritalStatus === "partnered") && (
                      <div>
                        <label className="block mb-2 text-sm">Spouse/Partner Occupation</label>
                        <input
                          type="text"
                          value={formData.spouseOccupation}
                          onChange={(e) => updateFormData("spouseOccupation", e.target.value)}
                          className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="Teacher"
                        />
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Annual Household Income *</label>
                    <select
                      required
                      value={formData.householdIncome}
                      onChange={(e) => updateFormData("householdIncome", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="under50k">Under $50,000</option>
                      <option value="50k-75k">$50,000 - $75,000</option>
                      <option value="75k-100k">$75,000 - $100,000</option>
                      <option value="100k-150k">$100,000 - $150,000</option>
                      <option value="over150k">Over $150,000</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Do you currently have children? *</label>
                    <select
                      required
                      value={formData.currentChildren}
                      onChange={(e) => updateFormData("currentChildren", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="no">No</option>
                      <option value="yes-1">Yes, 1 child</option>
                      <option value="yes-2">Yes, 2 children</option>
                      <option value="yes-3plus">Yes, 3+ children</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Living Situation */}
            {currentStep === 3 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl mb-6 text-foreground">Living Situation</h2>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block mb-2 text-sm">Residence Type *</label>
                      <select
                        required
                        value={formData.residenceType}
                        onChange={(e) => updateFormData("residenceType", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      >
                        <option value="">Select...</option>
                        <option value="house-owned">House (Owned)</option>
                        <option value="house-rented">House (Rented)</option>
                        <option value="apartment-owned">Apartment (Owned)</option>
                        <option value="apartment-rented">Apartment (Rented)</option>
                        <option value="condo">Condominium</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block mb-2 text-sm">Years at Current Residence *</label>
                      <input
                        type="number"
                        required
                        min="0"
                        value={formData.yearsAtResidence}
                        onChange={(e) => updateFormData("yearsAtResidence", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="5"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Street Address *</label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => updateFormData("address", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="123 Main Street"
                    />
                  </div>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block mb-2 text-sm">City *</label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => updateFormData("city", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="New York"
                      />
                    </div>
                    <div>
                      <label className="block mb-2 text-sm">State *</label>
                      <input
                        type="text"
                        required
                        value={formData.state}
                        onChange={(e) => updateFormData("state", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="NY"
                      />
                    </div>
                    <div>
                      <label className="block mb-2 text-sm">ZIP Code *</label>
                      <input
                        type="text"
                        required
                        value={formData.zipCode}
                        onChange={(e) => updateFormData("zipCode", e.target.value)}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="10001"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Adoption Preferences */}
            {currentStep === 4 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl mb-6 text-foreground">Adoption Preferences</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block mb-2 text-sm">Type of Adoption *</label>
                    <select
                      required
                      value={formData.adoptionType}
                      onChange={(e) => updateFormData("adoptionType", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="domestic-infant">Domestic Infant</option>
                      <option value="foster-care">Foster Care</option>
                      <option value="international">International</option>
                      <option value="not-sure">Not Sure Yet</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Preferred Age Range *</label>
                    <select
                      required
                      value={formData.preferredAgeRange}
                      onChange={(e) => updateFormData("preferredAgeRange", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="0-2">0-2 years (Infant/Toddler)</option>
                      <option value="3-5">3-5 years (Preschool)</option>
                      <option value="6-10">6-10 years (School Age)</option>
                      <option value="11-17">11-17 years (Teen)</option>
                      <option value="flexible">Flexible/Open</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Gender Preference *</label>
                    <select
                      required
                      value={formData.preferredGender}
                      onChange={(e) => updateFormData("preferredGender", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="no-preference">No Preference</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2 text-sm">Open to Special Needs? *</label>
                    <select
                      required
                      value={formData.openToSpecialNeeds}
                      onChange={(e) => updateFormData("openToSpecialNeeds", e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select...</option>
                      <option value="yes">Yes</option>
                      <option value="maybe">Maybe - Would like to discuss</option>
                      <option value="no">No</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Documents */}
            {currentStep === 5 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl mb-6 text-foreground">Document Upload</h2>
                <p className="text-muted-foreground mb-6">
                  Please upload the following documents. You can also submit these later via email.
                </p>
                <div className="space-y-6">
                  <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="mb-2 text-foreground">Upload Documents</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Drag and drop files here or click to browse
                    </p>
                    <input
                      type="file"
                      multiple
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors cursor-pointer inline-block"
                    >
                      Choose Files
                    </label>
                  </div>

                  <div className="bg-muted p-6 rounded-xl">
                    <h4 className="mb-3 text-foreground">Required Documents:</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Government-issued photo ID (Driver's License, Passport)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Proof of income (Recent pay stubs or tax returns)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Marriage certificate (if applicable)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Medical clearance form (will be provided)</span>
                      </li>
                    </ul>
                    <p className="text-xs text-muted-foreground mt-4">
                      * Don't have all documents ready? You can submit this application and upload 
                      documents later via our secure portal.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between mt-8">
              <button
                type="button"
                onClick={handlePrev}
                disabled={currentStep === 1}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors ${
                  currentStep === 1
                    ? "bg-muted text-muted-foreground cursor-not-allowed"
                    : "bg-white text-foreground border border-border hover:bg-muted"
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
                Previous
              </button>

              <div className="text-sm text-muted-foreground">
                Step {currentStep} of {totalSteps}
              </div>

              {currentStep < totalSteps ? (
                <button
                  type="button"
                  onClick={handleNext}
                  className="flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors"
                >
                  Next
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors"
                >
                  Submit Application
                  <CheckCircle className="w-4 h-4" />
                </button>
              )}
            </div>
          </form>
        </div>
      </section>
    </div>
  );
}
