import { Link } from "react-router";
import { Heart, Users, Award, Clock, ArrowRight, Shield, CheckCircle } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Home() {
  const stats = [
    { icon: Heart, label: "Children Helped", value: "1,200+" },
    { icon: Users, label: "Families Matched", value: "850+" },
    { icon: Award, label: "Years of Service", value: "25+" },
    { icon: Clock, label: "Avg. Placement Time", value: "6-12 mo" },
  ];

  const successStories = [
    {
      image: "https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZmFtaWx5JTIwY2hpbGRyZW4lMjBoYXBwaW5lc3N8ZW58MXx8fHwxNzcwMzY5NDUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "Our family is now complete. The journey was emotional, but every step was worth it.",
      family: "The Johnson Family",
    },
    {
      image: "https://images.unsplash.com/photo-1758631516588-87893aa348c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMGFkb3B0aW9uJTIwY29tcGFzc2lvbnxlbnwxfHx8fDE3NzAzNjk0NTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "We found hope and endless love. Thank you for making our dreams come true.",
      family: "The Martinez Family",
    },
    {
      image: "https://images.unsplash.com/photo-1767411972844-b5e8bdda9e5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBsb3ZlJTIwd2FybXRofGVufDF8fHx8MTc3MDM2OTQ1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "The support we received throughout the process was incredible. Our son is home!",
      family: "The Chen Family",
    },
  ];

  const trustBadges = [
    { icon: Shield, label: "CARF Certified" },
    { icon: CheckCircle, label: "Government Licensed" },
    { icon: Award, label: "JCICS Member" },
    { icon: Heart, label: "Hague Accredited" },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl xl:text-6xl mb-6 text-foreground">
                Start Your <span className="text-primary">Adoption Journey</span> Today
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Every child deserves a loving family. Every family deserves the joy of a child. 
                We're here to make that connection with compassion, transparency, and unwavering support.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/apply"
                  className="bg-primary text-white px-8 py-4 rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center justify-center gap-2"
                >
                  Begin Application
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/adoption-process"
                  className="bg-white text-primary border-2 border-primary px-8 py-4 rounded-lg hover:bg-primary/5 transition-colors inline-flex items-center justify-center"
                >
                  Learn How It Works
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZmFtaWx5JTIwY2hpbGRyZW4lMjBoYXBwaW5lc3N8ZW58MXx8fHwxNzcwMzY5NDUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Happy diverse family"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Our Mission</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            At Hearts & Homes, we believe every child has the right to grow up in a safe, nurturing, 
            and permanent family. Our mission is to connect children in need with loving families through 
            ethical, transparent adoption practices. We prioritize child welfare, support birth parents 
            with compassion, and guide adoptive families with expertise and care at every step.
          </p>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                    <Icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-3xl lg:text-4xl text-primary mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Success Stories Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Success Stories</h2>
            <p className="text-lg text-muted-foreground">
              Real families. Real journeys. Real love.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {successStories.map((story, index) => (
              <div key={index} className="bg-card rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="aspect-[4/3] overflow-hidden">
                  <ImageWithFallback
                    src={story.image}
                    alt={`${story.family} adoption story`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <p className="text-muted-foreground italic mb-4">"{story.quote}"</p>
                  <p className="text-sm text-primary">— {story.family}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/success-stories"
              className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
            >
              Read More Stories
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Licensed & Trusted</h2>
            <p className="text-lg text-muted-foreground">
              Accredited by leading organizations to ensure the highest standards
            </p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {trustBadges.map((badge, index) => {
              const Icon = badge.icon;
              return (
                <div key={index} className="flex flex-col items-center gap-3">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-md">
                    <Icon className="w-10 h-10 text-primary" />
                  </div>
                  <span className="text-sm text-center">{badge.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6">Ready to Take the First Step?</h2>
          <p className="text-lg mb-8 text-white/90">
            Our team is here to answer your questions and guide you through every stage of the adoption journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-white text-primary px-8 py-4 rounded-lg hover:bg-white/90 transition-colors inline-flex items-center justify-center"
            >
              Contact Us
            </Link>
            <Link
              to="/resources"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white/10 transition-colors inline-flex items-center justify-center"
            >
              Browse Resources
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
