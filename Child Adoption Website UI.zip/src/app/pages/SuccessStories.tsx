import { Quote, Heart, Calendar } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Link } from "react-router";

export function SuccessStories() {
  const stories = [
    {
      family: "The Martinez Family",
      childName: "Sofia",
      adoptionDate: "June 2024",
      image: "https://images.unsplash.com/photo-1588977827076-b4db84d29151?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGFkb3B0ZWQlMjBmYW1pbHklMjB0b2dldGhlcnxlbnwxfHx8fDE3NzAzNjk3NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "When we first met Sofia, we knew she was meant to be part of our family. The journey had its challenges, but the Hearts & Homes team supported us every step of the way. Today, watching her laugh and play with her siblings fills our hearts with joy we never thought possible.",
      longStory: "We began our adoption journey after years of hoping to expand our family. The process seemed overwhelming at first, but our social worker guided us with patience and compassion. The home study helped us prepare emotionally and practically. When we were matched with Sofia, a bright 6-year-old with an infectious smile, we felt an instant connection. The transition period had its ups and downs, but the post-adoption counseling and support groups were invaluable. Two years later, Sofia is thriving in school, has made wonderful friends, and our bond grows stronger every day.",
    },
    {
      family: "The Johnson Family",
      childName: "Marcus & Lily",
      adoptionDate: "March 2025",
      image: "https://images.unsplash.com/photo-1662441899356-4f97ef5fca81?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBhZG9wdGlvbiUyMGNlbGVicmF0aW9ufGVufDF8fHx8MTc3MDM2OTc3Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "We always said we wanted to adopt siblings so they could stay together. Marcus and Lily have brought so much love and laughter into our home. Watching them grow confident in their new environment has been the greatest gift of our lives.",
      longStory: "As a couple who struggled with infertility, adoption became our path to parenthood. We were open to special needs adoption and specifically wanted to keep siblings together. When we learned about Marcus (8) and Lily (5), who had been in foster care together, we felt called to meet them. The bonding process was gradual but beautiful. Marcus was protective of Lily at first, but slowly they both learned to trust us. Now, a year later, they call us Mom and Dad, and we can't imagine life without their energy, creativity, and endless questions filling our home.",
    },
    {
      family: "The Chen Family",
      childName: "Emma",
      adoptionDate: "October 2024",
      image: "https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZmFtaWx5JTIwY2hpbGRyZW4lMjBoYXBwaW5lc3N8ZW58MXx8fHwxNzcwMzY5NDUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "Emma came into our lives like a ray of sunshine. As first-time parents, we had so many questions and fears, but Hearts & Homes never made us feel alone. The education we received prepared us well, and the ongoing support has been incredible.",
      longStory: "We were first-time parents navigating the world of domestic infant adoption. The waiting period was emotionally challenging, but the preparation classes helped us understand what to expect. When Emma's birth mother chose us, we were overwhelmed with gratitude and responsibility. The hospital placement day was surreal – holding our daughter for the first time, meeting her brave birth mother who made the most selfless decision. We maintain a semi-open adoption with annual letters and photos. Emma is now 18 months old, healthy, happy, and already showing signs of her strong personality.",
    },
    {
      family: "The Williams Family",
      childName: "Daniel",
      adoptionDate: "January 2025",
      image: "https://images.unsplash.com/photo-1588977827076-b4db84d29151?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGFkb3B0ZWQlMjBmYW1pbHklMjB0b2dldGhlcnxlbnwxfHx8fDE3NzAzNjk3NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "As a single parent, I worried if I could provide everything a child needs. But Daniel has shown me that love, stability, and commitment are what matter most. We're a team now, and I'm so proud to be his dad.",
      longStory: "I began my adoption journey as a single man in my late 30s. Some people questioned my decision, but I knew I had love to give and a stable home to offer. The home study process was thorough but fair. I was matched with Daniel, a 7-year-old who needed a patient, structured environment. He had experienced trauma in his early life, and we worked closely with therapists to help him heal. It wasn't always easy – there were setbacks and challenging days. But watching him go from withdrawn to opening up, from struggling in school to thriving, has been the most rewarding experience of my life.",
    },
    {
      family: "The Patel Family",
      childName: "Grace",
      adoptionDate: "August 2024",
      image: "https://images.unsplash.com/photo-1662441899356-4f97ef5fca81?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBhZG9wdGlvbiUyMGNlbGVicmF0aW9ufGVufDF8fHx8MTc3MDM2OTc3Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "International adoption felt complex and overwhelming, but Hearts & Homes made it manageable. Meeting Grace in her home country was life-changing. Now she's learning about both her birth culture and ours, and we celebrate both as part of who she is.",
      longStory: "We pursued international adoption to honor our desire to provide a home for a child in need while embracing cultural diversity. The process took nearly two years, including paperwork, home studies, and immigration procedures. When we finally traveled to meet 4-year-old Grace, our hearts melted. The transition had challenges – language barriers, adjustment to new surroundings, processing grief from leaving her foster family. We connected with cultural communities to help Grace maintain ties to her heritage. Now, at age 6, she's bilingual, confident, and deeply loved. We're grateful every day for the opportunity to be her parents.",
    },
    {
      family: "The Anderson Family",
      childName: "Tyler",
      adoptionDate: "May 2025",
      image: "https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZmFtaWx5JTIwY2hpbGRyZW4lMjBoYXBwaW5lc3N8ZW58MXx8fHwxNzcwMzY5NDUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      quote: "Adopting an older teen was the best decision we ever made. Tyler brought wisdom, humor, and perspective to our family. He's taught us as much as we've taught him. We're honored to be the family he deserves.",
      longStory: "Many people asked why we wanted to adopt a teenager when we already had two young children. But we felt called to provide a permanent family for an older youth who might otherwise age out of the system. Tyler was 15, skeptical, and guarded when we first met. He'd been in multiple placements and didn't believe in 'forever families.' Building trust took time. We focused on consistency, respect, and showing up – every single day. Slowly, he began to believe we weren't going anywhere. Now 17, Tyler is a beloved big brother, an honors student, and planning for college. He tells us we gave him hope, but truly, he gave us perspective on what matters most: unconditional love and commitment.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">Success Stories</h1>
          <p className="text-lg text-muted-foreground">
            Real families sharing their adoption journeys – the challenges, the joy, and the love
          </p>
        </div>
      </section>

      {/* Stories Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {stories.map((story, index) => {
              const isEven = index % 2 === 0;
              
              return (
                <div
                  key={index}
                  className={`grid lg:grid-cols-2 gap-12 items-center ${
                    isEven ? "" : "lg:grid-flow-dense"
                  }`}
                >
                  {/* Image */}
                  <div className={isEven ? "" : "lg:col-start-2"}>
                    <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
                      <ImageWithFallback
                        src={story.image}
                        alt={`${story.family} adoption story`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* Content */}
                  <div className={isEven ? "" : "lg:col-start-1 lg:row-start-1"}>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <Heart className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h2 className="text-2xl text-foreground">{story.family}</h2>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          <span>Adopted {story.childName} • {story.adoptionDate}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-accent/10 p-6 rounded-xl border-l-4 border-primary mb-6">
                      <Quote className="w-8 h-8 text-primary mb-3" />
                      <p className="text-muted-foreground italic leading-relaxed">
                        "{story.quote}"
                      </p>
                    </div>

                    <p className="text-muted-foreground leading-relaxed">
                      {story.longStory}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonial Stats */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4">The Impact of Adoption</h2>
            <p className="text-lg text-white/90">
              Numbers that represent lives transformed
            </p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl mb-2">850+</div>
              <div className="text-sm text-white/80">Families Created</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl mb-2">98%</div>
              <div className="text-sm text-white/80">Success Rate</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl mb-2">1,200+</div>
              <div className="text-sm text-white/80">Children Placed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl mb-2">25</div>
              <div className="text-sm text-white/80">Years of Service</div>
            </div>
          </div>
        </div>
      </section>

      {/* Share Your Story */}
      <section className="py-16 bg-muted">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Share Your Story</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Are you a Hearts & Homes adoptive family? We'd love to hear about your journey and 
            share your story (with your permission) to inspire others.
          </p>
          <Link
            to="/contact"
            className="bg-primary text-white px-8 py-4 rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center justify-center gap-2"
          >
            <Heart className="w-5 h-5" />
            Submit Your Story
          </Link>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Ready to Write Your Own Story?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Every adoption journey is unique. Let us help you write yours.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/apply"
              className="bg-primary text-white px-8 py-4 rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center justify-center"
            >
              Start Application
            </Link>
            <Link
              to="/contact"
              className="bg-white text-primary border-2 border-primary px-8 py-4 rounded-lg hover:bg-primary/5 transition-colors inline-flex items-center justify-center"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
