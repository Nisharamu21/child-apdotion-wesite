import { useState } from "react";
import { FileText, Download, BookOpen, Scale, Heart, HelpCircle, ChevronDown } from "lucide-react";
import { Link } from "react-router";

export function Resources() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const resources = [
    {
      icon: FileText,
      title: "Adoption Guide",
      description: "Comprehensive guide covering all aspects of the adoption process",
      size: "2.3 MB",
    },
    {
      icon: BookOpen,
      title: "Emotional Preparation Handbook",
      description: "Help prepare your heart and home for adoption",
      size: "1.8 MB",
    },
    {
      icon: Scale,
      title: "Legal Rights & Responsibilities",
      description: "Understanding your legal obligations as adoptive parents",
      size: "1.2 MB",
    },
    {
      icon: Heart,
      title: "Post-Adoption Support Guide",
      description: "Resources for life after bringing your child home",
      size: "2.1 MB",
    },
  ];

  const faqs = [
    {
      category: "General",
      question: "What types of adoption do you offer?",
      answer: "We facilitate domestic infant adoption, foster care adoption, and international adoption. Each type has different requirements, timelines, and costs. Our team can help you determine which path is right for your family during your initial consultation.",
    },
    {
      category: "General",
      question: "Who can adopt?",
      answer: "We welcome applications from married couples, single individuals, and LGBTQ+ families. Basic requirements include being at least 21 years old, having stable income and housing, passing background checks, and demonstrating the ability to provide a safe, loving home.",
    },
    {
      category: "Process",
      question: "How long does the adoption process take?",
      answer: "The timeline varies significantly based on the type of adoption and individual circumstances. Domestic infant adoption typically takes 1-2 years, foster care adoption 6-18 months, and international adoption 1-3 years. We provide regular updates throughout your journey.",
    },
    {
      category: "Process",
      question: "What is a home study?",
      answer: "A home study is a comprehensive evaluation conducted by a licensed social worker. It includes interviews, home visits, background checks, and reference checks. The purpose is to ensure you can provide a safe, nurturing environment and to prepare you for adoption.",
    },
    {
      category: "Financial",
      question: "How much does adoption cost?",
      answer: "Costs vary by adoption type. Domestic infant adoption: $20,000-$45,000; Foster care adoption: Often free or under $3,000 with subsidies; International adoption: $25,000-$50,000. We provide detailed cost breakdowns and information about tax credits, grants, and financing options.",
    },
    {
      category: "Financial",
      question: "Are there financial assistance options available?",
      answer: "Yes! Options include the federal adoption tax credit (up to $15,950), employer adoption benefits, adoption grants from various organizations, low-interest loans, and state subsidies for foster care adoption. We help families explore all available financial resources.",
    },
    {
      category: "Post-Adoption",
      question: "What support do you provide after adoption?",
      answer: "We offer ongoing post-adoption services including counseling, support groups, educational workshops, crisis intervention, and access to specialized resources. Our commitment to your family continues long after finalization.",
    },
    {
      category: "Post-Adoption",
      question: "Can we maintain contact with birth parents?",
      answer: "This depends on the type of adoption and mutual agreement. Open adoption allows ongoing contact (visits, letters, photos), semi-open involves mediated communication, and closed adoption has no identifying information shared. We support all arrangements that prioritize the child's best interests.",
    },
  ];

  const legalInfo = [
    {
      title: "Federal Adoption Laws",
      points: [
        "Indian Child Welfare Act (ICWA)",
        "Multiethnic Placement Act (MEPA)",
        "Adoption and Safe Families Act (ASFA)",
        "Hague Convention on Intercountry Adoption",
      ],
    },
    {
      title: "Your Rights as Adoptive Parents",
      points: [
        "Right to full disclosure about the child's background and medical history",
        "Right to legal representation throughout the process",
        "Right to withdraw from the process at any time before finalization",
        "Right to appeal if application is denied",
      ],
    },
    {
      title: "State-Specific Requirements",
      points: [
        "Minimum age requirements (typically 21+)",
        "Background check and fingerprinting",
        "Mandatory training and education hours",
        "Post-placement supervision periods",
      ],
    },
  ];

  const categories = ["All", "General", "Process", "Financial", "Post-Adoption"];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredFaqs = selectedCategory === "All" 
    ? faqs 
    : faqs.filter(faq => faq.category === selectedCategory);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">Adoption Resources</h1>
          <p className="text-lg text-muted-foreground">
            Everything you need to know about adoption, from FAQs to downloadable guides
          </p>
        </div>
      </section>

      {/* Downloadable Resources */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Downloadable Guides</h2>
            <p className="text-lg text-muted-foreground">
              Free resources to help you on your adoption journey
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {resources.map((resource, index) => {
              const Icon = resource.icon;
              return (
                <div key={index} className="bg-muted p-6 rounded-xl hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-lg">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg mb-2 text-foreground">{resource.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {resource.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">PDF • {resource.size}</span>
                        <button className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
                          <Download className="w-4 h-4" />
                          <span className="text-sm">Download</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16 bg-muted">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Frequently Asked Questions</h2>
            <p className="text-lg text-muted-foreground">
              Quick answers to common adoption questions
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-white"
                    : "bg-white text-foreground hover:bg-primary/10"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* FAQ Accordion */}
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-xl overflow-hidden shadow-sm">
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full p-6 text-left flex items-center justify-between hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="pr-4 text-foreground">{faq.question}</span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground transition-transform flex-shrink-0 ${
                      openFaq === index ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-6 text-muted-foreground">
                    <div className="border-t border-border pt-4">
                      {faq.answer}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Legal Information */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Legal Information</h2>
            <p className="text-lg text-muted-foreground">
              Understanding the legal aspects of adoption
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {legalInfo.map((section, index) => (
              <div key={index} className="bg-muted p-6 rounded-xl">
                <h3 className="text-xl mb-4 text-foreground">{section.title}</h3>
                <ul className="space-y-3">
                  {section.points.map((point, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Scale className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-8 p-6 bg-accent/10 rounded-xl border-l-4 border-primary">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Disclaimer:</strong> This information is for educational 
              purposes only and does not constitute legal advice. Please consult with a qualified adoption 
              attorney for guidance specific to your situation.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6">Still Have Questions?</h2>
          <p className="text-lg mb-8 text-white/90">
            Our experienced team is here to help. Contact us for personalized guidance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-white text-primary px-8 py-4 rounded-lg hover:bg-white/90 transition-colors inline-flex items-center justify-center"
            >
              Contact Support
            </Link>
            <Link
              to="/apply"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white/10 transition-colors inline-flex items-center justify-center"
            >
              Start Application
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
