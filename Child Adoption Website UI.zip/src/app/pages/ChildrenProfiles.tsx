import { useState } from "react";
import { Heart, Search, Filter } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Link } from "react-router";

interface ChildProfile {
  id: string;
  name: string;
  ageRange: string;
  gender: string;
  interests: string[];
  personality: string;
  specialNeeds: boolean;
  image: string;
}

export function ChildrenProfiles() {
  const [selectedGender, setSelectedGender] = useState("All");
  const [selectedAge, setSelectedAge] = useState("All");
  const [showSpecialNeeds, setShowSpecialNeeds] = useState(false);

  const childrenProfiles: ChildProfile[] = [
    {
      id: "1",
      name: "Alex",
      ageRange: "5-7 years",
      gender: "Male",
      interests: ["Sports", "Music", "Animals"],
      personality: "Energetic, loving, and curious. Enjoys outdoor activities and making new friends.",
      specialNeeds: false,
      image: "https://images.unsplash.com/photo-1597113117918-eb40fe0b84e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGNoaWxkJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzcwMzY5NjM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "2",
      name: "Sophia",
      ageRange: "8-10 years",
      gender: "Female",
      interests: ["Reading", "Art", "Dancing"],
      personality: "Creative, thoughtful, and kind-hearted. Loves storytelling and helping others.",
      specialNeeds: false,
      image: "https://images.unsplash.com/photo-1761168433666-b5d7396c835e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsaW5nJTIwY2hpbGRyZW4lMjBkaXZlcnNlfGVufDF8fHx8MTc3MDM2OTY0MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "3",
      name: "Jordan",
      ageRange: "11-13 years",
      gender: "Male",
      interests: ["Video Games", "Science", "Basketball"],
      personality: "Intelligent, loyal, and determined. Strong interest in learning and technology.",
      specialNeeds: true,
      image: "https://images.unsplash.com/photo-1637195789142-27f844c316ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMHBsYXlpbmclMjBvdXRkb29yc3xlbnwxfHx8fDE3NzAzNjk2NDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "4",
      name: "Emma",
      ageRange: "3-5 years",
      gender: "Female",
      interests: ["Singing", "Playing", "Stuffed Animals"],
      personality: "Sweet, playful, and affectionate. Enjoys cuddles and imaginative play.",
      specialNeeds: false,
      image: "https://images.unsplash.com/photo-1597113117918-eb40fe0b84e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGNoaWxkJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzcwMzY5NjM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "5",
      name: "Liam",
      ageRange: "8-10 years",
      gender: "Male",
      interests: ["Building", "Nature", "Cooking"],
      personality: "Patient, creative, and resourceful. Loves hands-on activities and exploration.",
      specialNeeds: true,
      image: "https://images.unsplash.com/photo-1637195789142-27f844c316ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMHBsYXlpbmclMjBvdXRkb29yc3xlbnwxfHx8fDE3NzAzNjk2NDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "6",
      name: "Mia",
      ageRange: "5-7 years",
      gender: "Female",
      interests: ["Drawing", "Puzzles", "Pets"],
      personality: "Gentle, observant, and compassionate. Thrives with routine and structure.",
      specialNeeds: false,
      image: "https://images.unsplash.com/photo-1761168433666-b5d7396c835e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsaW5nJTIwY2hpbGRyZW4lMjBkaXZlcnNlfGVufDF8fHx8MTc3MDM2OTY0MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
  ];

  const filteredProfiles = childrenProfiles.filter((child) => {
    const genderMatch = selectedGender === "All" || child.gender === selectedGender;
    const ageMatch = selectedAge === "All" || child.ageRange === selectedAge;
    const specialNeedsMatch = !showSpecialNeeds || child.specialNeeds;
    
    return genderMatch && ageMatch && specialNeedsMatch;
  });

  const ageRanges = ["All", "3-5 years", "5-7 years", "8-10 years", "11-13 years"];
  const genders = ["All", "Male", "Female"];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">Children Waiting for Families</h1>
          <p className="text-lg text-muted-foreground">
            Every child deserves a loving home. Learn about children ready to join a forever family.
          </p>
        </div>
      </section>

      {/* Important Notice */}
      <section className="py-8 bg-accent/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white p-6 rounded-xl border-l-4 border-primary">
            <div className="flex items-start gap-4">
              <Heart className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="mb-2 text-foreground">Privacy & Respect</h3>
                <p className="text-sm text-muted-foreground">
                  To protect children's privacy, profiles contain general information only. Names have been 
                  changed. Detailed information, photos, and full backgrounds are shared only with approved 
                  adoptive families during the matching process. All information is handled with the utmost 
                  care and confidentiality.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white sticky top-16 z-40 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
            <div className="flex items-center gap-2 text-foreground">
              <Filter className="w-5 h-5" />
              <span>Filter By:</span>
            </div>
            
            <div className="flex flex-wrap gap-4 flex-1">
              {/* Age Filter */}
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Age Range</label>
                <select
                  value={selectedAge}
                  onChange={(e) => setSelectedAge(e.target.value)}
                  className="bg-muted border border-border rounded-lg px-4 py-2 text-sm"
                >
                  {ageRanges.map((age) => (
                    <option key={age} value={age}>
                      {age}
                    </option>
                  ))}
                </select>
              </div>

              {/* Gender Filter */}
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Gender</label>
                <select
                  value={selectedGender}
                  onChange={(e) => setSelectedGender(e.target.value)}
                  className="bg-muted border border-border rounded-lg px-4 py-2 text-sm"
                >
                  {genders.map((gender) => (
                    <option key={gender} value={gender}>
                      {gender}
                    </option>
                  ))}
                </select>
              </div>

              {/* Special Needs Filter */}
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Special Needs</label>
                <label className="flex items-center gap-2 cursor-pointer bg-muted border border-border rounded-lg px-4 py-2">
                  <input
                    type="checkbox"
                    checked={showSpecialNeeds}
                    onChange={(e) => setShowSpecialNeeds(e.target.checked)}
                    className="accent-primary"
                  />
                  <span className="text-sm">Only show special needs</span>
                </label>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              {filteredProfiles.length} {filteredProfiles.length === 1 ? 'child' : 'children'} found
            </div>
          </div>
        </div>
      </section>

      {/* Children Profiles Grid */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredProfiles.length === 0 ? (
            <div className="text-center py-12">
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl mb-2 text-foreground">No profiles match your filters</h3>
              <p className="text-muted-foreground">Try adjusting your search criteria</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProfiles.map((child) => (
                <div
                  key={child.id}
                  className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="aspect-square overflow-hidden bg-muted">
                    <ImageWithFallback
                      src={child.image}
                      alt={`Child profile ${child.id}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl mb-1 text-foreground">{child.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {child.ageRange} • {child.gender}
                        </p>
                      </div>
                      {child.specialNeeds && (
                        <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded">
                          Special Needs
                        </span>
                      )}
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="text-sm mb-2 text-foreground">Interests:</h4>
                      <div className="flex flex-wrap gap-2">
                        {child.interests.map((interest, idx) => (
                          <span
                            key={idx}
                            className="text-xs bg-secondary/30 text-secondary-foreground px-3 py-1 rounded-full"
                          >
                            {interest}
                          </span>
                        ))}
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                      {child.personality}
                    </p>

                    <Link
                      to="/contact"
                      className="w-full bg-primary text-white px-4 py-3 rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center justify-center gap-2"
                    >
                      <Heart className="w-4 h-4" />
                      Learn More
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Additional Information */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl mb-8 text-center text-foreground">
            About Special Needs Adoption
          </h2>
          <div className="space-y-4 text-muted-foreground">
            <p className="leading-relaxed">
              "Special needs" in adoption refers to children who may require additional support due to 
              medical conditions, developmental delays, emotional/behavioral challenges, or being part of 
              a sibling group. Many families find tremendous joy in special needs adoption.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Support Available:</strong> We provide specialized training, 
              ongoing counseling, access to medical and therapeutic resources, and financial assistance 
              (including monthly subsidies and medical coverage) for families adopting children with special needs.
            </p>
            <p className="leading-relaxed">
              <strong className="text-foreground">Every Child is Unique:</strong> "Special needs" is a broad 
              category. Each child has their own strengths, personality, and potential. We work closely with 
              families to ensure successful matches based on the family's capabilities and the child's needs.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6">Ready to Meet Your Match?</h2>
          <p className="text-lg mb-8 text-white/90">
            Contact us to learn more about these wonderful children and start the matching process.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/apply"
              className="bg-white text-primary px-8 py-4 rounded-lg hover:bg-white/90 transition-colors inline-flex items-center justify-center"
            >
              Start Application
            </Link>
            <Link
              to="/contact"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white/10 transition-colors inline-flex items-center justify-center"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
