import { 
  CheckCircle, 
  FileText, 
  Home, 
  Heart, 
  Scale, 
  Users,
  ArrowRight,
  Clock,
  AlertCircle
} from "lucide-react";
import { Link } from "react-router";

export function AdoptionProcess() {
  const steps = [
    {
      number: 1,
      icon: CheckCircle,
      title: "Eligibility Check",
      duration: "1-2 weeks",
      description: "Initial consultation to discuss your family situation, motivations for adoption, and basic eligibility requirements.",
      requirements: [
        "Age requirement: 21+ years old",
        "Stable income and housing",
        "Pass background checks",
        "Complete health screening",
      ],
    },
    {
      number: 2,
      icon: FileText,
      title: "Application Submission",
      duration: "2-4 weeks",
      description: "Complete comprehensive application forms providing detailed information about your family, lifestyle, and preferences.",
      requirements: [
        "Personal and family history",
        "Financial documentation",
        "References from non-relatives",
        "Medical reports",
      ],
    },
    {
      number: 3,
      icon: Home,
      title: "Home Study",
      duration: "2-3 months",
      description: "A licensed social worker conducts interviews and home visits to ensure a safe, nurturing environment for a child.",
      requirements: [
        "Multiple in-person interviews",
        "Home safety inspection",
        "Criminal background checks",
        "Child abuse clearances",
      ],
    },
    {
      number: 4,
      icon: Heart,
      title: "Matching Process",
      duration: "3-12 months",
      description: "We carefully match you with a child whose needs align with your family's capabilities and preferences.",
      requirements: [
        "Review child profiles",
        "Meet potential matches",
        "Consider special needs",
        "Gradual introduction process",
      ],
    },
    {
      number: 5,
      icon: Scale,
      title: "Legal Process",
      duration: "3-6 months",
      description: "Finalize the adoption through court proceedings with full legal representation and support.",
      requirements: [
        "Placement agreement signed",
        "Court petition filed",
        "Finalization hearing",
        "Adoption decree issued",
      ],
    },
    {
      number: 6,
      icon: Users,
      title: "Post-Adoption Support",
      duration: "Ongoing",
      description: "Continued support and resources to help your family thrive together.",
      requirements: [
        "Follow-up home visits",
        "Counseling services",
        "Support groups",
        "Educational resources",
      ],
    },
  ];

  const faqs = [
    {
      question: "How long does the entire adoption process take?",
      answer: "The timeline varies, but typically ranges from 6 months to 2 years from initial application to finalization, depending on the type of adoption and specific circumstances.",
    },
    {
      question: "What are the costs involved?",
      answer: "Adoption costs vary by type. Domestic infant adoption typically ranges from $20,000-$45,000, while foster care adoption is often free or low-cost. We provide detailed cost breakdowns during consultation.",
    },
    {
      question: "Can single parents adopt?",
      answer: "Yes! Single individuals who meet eligibility requirements are welcome to adopt. We support diverse family structures.",
    },
    {
      question: "Do I need to own a home?",
      answer: "No, home ownership is not required. You need safe, stable housing appropriate for a child, whether owned or rented.",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl mb-6 text-foreground">The Adoption Process</h1>
          <p className="text-lg text-muted-foreground">
            A clear, step-by-step guide to your adoption journey. We're with you every step of the way.
          </p>
        </div>
      </section>

      {/* Timeline Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl mb-4 text-foreground">Six Steps to Your Forever Family</h2>
            <p className="text-lg text-muted-foreground">
              Average total timeline: 6-24 months
            </p>
          </div>

          <div className="space-y-12">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;
              
              return (
                <div key={step.number} className="relative">
                  {/* Connector Line (except for last item) */}
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute left-1/2 top-24 w-0.5 h-24 bg-border transform -translate-x-1/2" />
                  )}
                  
                  <div className={`grid lg:grid-cols-2 gap-8 items-center ${isEven ? '' : 'lg:flex-row-reverse'}`}>
                    {/* Content */}
                    <div className={`${isEven ? 'lg:text-right' : 'lg:order-2'}`}>
                      <div className={`inline-block ${isEven ? 'lg:float-right' : ''}`}>
                        <div className="flex items-center gap-3 mb-4">
                          {!isEven && (
                            <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center">
                              <Icon className="w-7 h-7 text-primary" />
                            </div>
                          )}
                          <div>
                            <div className="text-sm text-primary mb-1">Step {step.number}</div>
                            <h3 className="text-2xl text-foreground">{step.title}</h3>
                          </div>
                          {isEven && (
                            <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center">
                              <Icon className="w-7 h-7 text-primary" />
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mb-4 text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm">{step.duration}</span>
                        </div>
                        <p className="text-muted-foreground mb-4">{step.description}</p>
                      </div>
                    </div>

                    {/* Requirements Card */}
                    <div className={isEven ? '' : 'lg:order-1'}>
                      <div className="bg-muted p-6 rounded-xl">
                        <h4 className="mb-3 text-foreground">Key Requirements:</h4>
                        <ul className="space-y-2">
                          {step.requirements.map((req, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                              <span>{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Important Information */}
      <section className="py-16 bg-accent/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white p-8 rounded-xl border-l-4 border-primary">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-lg">
                <AlertCircle className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl mb-3 text-foreground">Important to Know</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Timelines vary based on adoption type, child's needs, and individual circumstances</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>We provide comprehensive support and guidance throughout each step</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Required training and education programs are provided at no additional cost</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>You can pause the process at any time if needed</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl mb-12 text-center text-foreground">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-muted p-6 rounded-xl">
                <h3 className="text-lg mb-3 text-foreground">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              to="/resources"
              className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
            >
              View All FAQs
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6">Ready to Begin Your Journey?</h2>
          <p className="text-lg mb-8 text-white/90">
            Schedule a free consultation to discuss your adoption goals and learn more about the process.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/apply"
              className="bg-white text-primary px-8 py-4 rounded-lg hover:bg-white/90 transition-colors inline-flex items-center justify-center gap-2"
            >
              Start Application
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/contact"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white/10 transition-colors inline-flex items-center justify-center"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
