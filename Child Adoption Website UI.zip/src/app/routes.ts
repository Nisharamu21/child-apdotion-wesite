import { createBrowserRouter } from "react-router";
import { Root } from "./pages/Root";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { AdoptionProcess } from "./pages/AdoptionProcess";
import { ChildrenProfiles } from "./pages/ChildrenProfiles";
import { Apply } from "./pages/Apply";
import { Resources } from "./pages/Resources";
import { SuccessStories } from "./pages/SuccessStories";
import { Contact } from "./pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "about", Component: About },
      { path: "adoption-process", Component: AdoptionProcess },
      { path: "children", Component: ChildrenProfiles },
      { path: "apply", Component: Apply },
      { path: "resources", Component: Resources },
      { path: "success-stories", Component: SuccessStories },
      { path: "contact", Component: Contact },
    ],
  },
]);
